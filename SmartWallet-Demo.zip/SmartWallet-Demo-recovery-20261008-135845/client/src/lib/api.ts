const USER_KEY = "smartwallet.demoUserId";

export function getUserId() {
  return localStorage.getItem(USER_KEY) || "user-general";
}

export function setUserId(id: string) {
  localStorage.setItem(USER_KEY, id);
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "X-Demo-User-Id": getUserId(),
      ...(init?.headers ?? {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || "Error de demostración") as Error & {
      status: number;
      payload: unknown;
    };
    err.status = res.status;
    err.payload = data;
    throw err;
  }
  return data as T;
}

export const api = {
  catalog: () => request("/api/catalog"),
  wallet: () => request("/api/wallet"),
  movement: (id: string) => request(`/api/wallet/movements/${id}`),
  recharge: (amountCents: number) =>
    request("/api/recharges", { method: "POST", body: JSON.stringify({ amountCents }) }),
  settleRecharge: (id: string, outcome: "approved" | "rejected") =>
    request(`/api/recharges/${id}/simulate`, { method: "POST", body: JSON.stringify({ outcome }) }),
  createOrder: (body: unknown) => request("/api/orders", { method: "POST", body: JSON.stringify(body) }),
  getOrder: (id: string) => request(`/api/orders/${id}`),
  confirmPay: (body: unknown) =>
    request("/api/payments/confirm", { method: "POST", body: JSON.stringify(body) }),
  cancelPay: (body: unknown) =>
    request("/api/payments/cancel", { method: "POST", body: JSON.stringify(body) }),
  checkout: (body: unknown) =>
    request("/api/online/checkout", { method: "POST", body: JSON.stringify(body) }),
  refund: (movementId: string) =>
    request("/api/refunds", { method: "POST", body: JSON.stringify({ movementId }) }),
  admin: () => request("/api/admin/stats"),
  reset: () => request("/api/demo/reset", { method: "POST" }),
};
