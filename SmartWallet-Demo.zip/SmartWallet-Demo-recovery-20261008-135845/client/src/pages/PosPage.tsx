import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { QRCodeSVG } from "qrcode.react";
import { useApp } from "../lib/AppContext";
import { api } from "../lib/api";
import { usd } from "../lib/format";
import type { BrandId, PaymentOrder, Product } from "../types";

interface Line {
  product: Product;
  quantity: number;
}

export function PosPage() {
  const { catalog } = useApp();
  const [brandId, setBrandId] = useState<BrandId>("farmacias-economicas");
  const [lines, setLines] = useState<Line[]>([]);
  const [order, setOrder] = useState<PaymentOrder | null>(null);
  const [qr, setQr] = useState("");
  const [busy, setBusy] = useState(false);

  const products = catalog?.products.filter((p) => p.brandId === brandId) ?? [];
  const subtotal = lines.reduce((s, l) => s + l.product.priceCents * l.quantity, 0);

  function add(product: Product) {
    setOrder(null);
    setLines((prev) => {
      const found = prev.find((l) => l.product.id === product.id);
      if (found) return prev.map((l) => (l.product.id === product.id ? { ...l, quantity: l.quantity + 1 } : l));
      return [...prev, { product, quantity: 1 }];
    });
  }

  async function create() {
    if (!lines.length) return;
    setBusy(true);
    try {
      const data = (await api.createOrder({
        brandId,
        channel: "physical",
        items: lines.map((l) => ({ productId: l.product.id, quantity: l.quantity })),
      })) as { order: PaymentOrder; qrPayload: string };
      setOrder(data.order);
      setQr(data.qrPayload);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (!order || order.status !== "pending") return;
    const t = setInterval(async () => {
      const data = (await api.getOrder(order.id)) as { order: PaymentOrder };
      setOrder(data.order);
    }, 1500);
    return () => clearInterval(t);
  }, [order?.id, order?.status]);

  const statusUi = useMemo(() => {
    if (!order) return { label: "SIN ORDEN", cls: "bg-slate-200 text-slate-700" };
    if (order.status === "pending") return { label: "PENDIENTE DE PAGO", cls: "bg-amber-100 text-amber-800" };
    if (order.status === "approved") return { label: "PAGO APROBADO", cls: "bg-emerald-500 text-white" };
    if (order.status === "rejected") return { label: "PAGO RECHAZADO", cls: "bg-rose-500 text-white" };
    return { label: "ORDEN CANCELADA", cls: "bg-slate-700 text-white" };
  }, [order]);

  return (
    <div className="min-h-screen bg-slate-100">
      <div className="bg-ink-950 px-6 py-4 text-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold tracking-widest text-rose-300">VENDIX SIMULATOR — NO CONECTADO A FARMAENLACE</p>
            <h1 className="text-2xl font-bold">Caja de demostración</h1>
          </div>
          <div className="flex gap-2 text-sm">
            <Link to="/" className="rounded-full bg-white/10 px-3 py-1">App</Link>
            <Link to="/admin" className="rounded-full bg-white/10 px-3 py-1">Admin</Link>
          </div>
        </div>
      </div>
      <div className="sticky top-0 z-10 bg-rose-600 py-2 text-center text-xs font-bold uppercase tracking-wide text-white">
        VENDIX SIMULATOR — NO CONECTADO A FARMAENLACE
      </div>
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-2">
        <section className="rounded-3xl bg-white p-5 shadow-sm">
          <label className="text-sm font-bold">Marca</label>
          <select
            value={brandId}
            onChange={(e) => {
              setBrandId(e.target.value as BrandId);
              setLines([]);
              setOrder(null);
            }}
            className="mt-1 w-full rounded-2xl bg-slate-50 px-3 py-2"
          >
            {catalog?.brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {products.map((p) => (
              <button key={p.id} onClick={() => add(p)} className="rounded-2xl border border-slate-100 p-3 text-left hover:bg-slate-50">
                <p className="text-sm font-semibold">{p.name}</p>
                <p className="text-xs text-slate-500">{usd(p.priceCents)}</p>
              </button>
            ))}
          </div>
          <ul className="mt-4 space-y-1 text-sm">
            {lines.map((l) => (
              <li key={l.product.id} className="flex justify-between">
                <span>
                  {l.quantity} × {l.product.name}
                </span>
                <span>{usd(l.product.priceCents * l.quantity)}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-lg font-bold">Total: {usd(subtotal)}</p>
          <p className="text-xs text-slate-500">El descuento de socio, si aplica, se calcula al confirmar en la billetera.</p>
          <button disabled={busy || !lines.length} onClick={create} className="mt-4 w-full rounded-2xl bg-ink-900 py-3 font-bold text-white">
            Crear orden de cobro
          </button>
        </section>
        <section className="rounded-3xl bg-white p-5 shadow-sm">
          <div className={`rounded-2xl px-4 py-3 text-center text-lg font-black ${statusUi.cls}`}>{statusUi.label}</div>
          {order ? (
            <div className="mt-4 text-center">
              <p className="text-sm text-slate-500">Referencia de pago (única)</p>
              <p className="font-mono text-xl font-bold">{order.reference}</p>
              <div className="mx-auto mt-4 w-fit rounded-3xl bg-white p-4 ring-1 ring-slate-200">
                <QRCodeSVG value={qr} size={220} />
              </div>
              <p className="mt-3 text-xs text-slate-500">
                El QR solo contiene: {qr}. Sin tarjetas ni secretos.
              </p>
              <p className="mt-2 text-sm">
                En SmartWallet abra <strong>Pagar con QR</strong> y escriba el código si no puede escanear localhost.
              </p>
              <p className="mt-2 text-sm">
                App: <Link className="font-semibold text-mint-600" to={`/wallet/pagar/${order.reference}`}>abrir cobro en esta computadora</Link>
              </p>
              {order.status === "approved" && (
                <p className="mt-4 rounded-2xl bg-emerald-50 p-3 font-semibold text-emerald-800">
                  Confirmación automática: el cliente pagó {usd(order.totalCents)}
                  {order.discountCents ? ` (descuento demo ${usd(order.discountCents)})` : ""}.
                </p>
              )}
            </div>
          ) : (
            <p className="mt-6 text-center text-slate-500">Cree una orden para generar el QR de demostración.</p>
          )}
        </section>
      </div>
    </div>
  );
}
