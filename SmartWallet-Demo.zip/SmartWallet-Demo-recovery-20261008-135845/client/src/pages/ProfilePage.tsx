import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../lib/AppContext";
import { api } from "../lib/api";
import { DemoBanner } from "../components/DemoBanner";

export function ProfilePage() {
  const { catalog, userId, setUser, refresh, wallet } = useApp();
  const navigate = useNavigate();

  async function reset() {
    if (!confirm("Esto restaura usuarios, saldos y catálogo de demostración. ¿Continuar?")) return;
    await api.reset();
    await refresh();
    navigate("/");
  }

  return (
    <div className="safe-bottom px-4 pt-6">
      <h1 className="text-2xl font-bold">Perfil</h1>
      <DemoBanner />
      <div className="mt-4 rounded-3xl bg-white p-4">
        <p className="text-sm text-slate-500">Usuario de prueba activo</p>
        <p className="text-xl font-bold">{wallet?.user.name}</p>
        <p className="text-sm">{wallet?.user.email}</p>
        <p className="text-sm text-slate-500">{wallet?.user.phone}</p>
      </div>
      <h2 className="mb-2 mt-5 text-sm font-bold">Cambiar perfil ficticio</h2>
      <div className="space-y-2">
        {catalog?.users.map((u) => (
          <button
            key={u.id}
            onClick={() => setUser(u.id)}
            className={`w-full rounded-2xl p-4 text-left ${userId === u.id ? "bg-ink-900 text-white" : "bg-white"}`}
          >
            <p className="font-bold">{u.name}</p>
            <p className="text-xs opacity-80">{u.isMember ? "Socio con membresía demo" : "Usuario general sin membresía"}</p>
          </button>
        ))}
      </div>
      <Link to="/membresia" className="mt-4 block rounded-2xl bg-amber-50 p-4 font-semibold text-amber-900">
        Ver membresía SmartClub
      </Link>
      <Link to="/admin" className="mt-2 block rounded-2xl bg-white p-4 font-semibold">
        Panel administrativo demo
      </Link>
      <Link to="/pos" className="mt-2 block rounded-2xl bg-white p-4 font-semibold">
        Caja VENDIX simulada
      </Link>
      <button onClick={reset} className="mt-6 w-full rounded-2xl bg-rose-50 py-3 font-bold text-rose-700">
        Reiniciar datos demo
      </button>
    </div>
  );
}
