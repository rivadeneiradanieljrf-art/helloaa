import { Link } from "react-router-dom";
import { Plus, QrCode } from "lucide-react";
import { DemoBanner } from "../components/DemoBanner";
import { useApp } from "../lib/AppContext";
import { channelLabel, formatDate, statusLabel, typeLabel, usd } from "../lib/format";

export function WalletPage() {
  const { wallet, brandName } = useApp();

  return (
    <div className="safe-bottom px-4 pt-6">
      <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">SmartClub · funcionalidad</p>
      <h1 className="text-2xl font-bold">SmartWallet</h1>
      <p className="text-sm text-slate-500">Tu dinero, todas tus marcas.</p>
      <div className="mt-3">
        <DemoBanner text="Todos los fondos de esta billetera son ficticios. No hay dinero real ni cuenta bancaria." />
      </div>

      <div className="mt-4 rounded-3xl bg-gradient-to-br from-ink-900 to-mint-600 p-5 text-white shadow-card">
        <p className="text-sm text-white/70">Saldo disponible</p>
        <p className="mt-1 text-4xl font-bold">{wallet ? usd(wallet.balanceCents) : "—"}</p>
        <p className="mt-2 text-xs text-white/70">{wallet?.user.name}</p>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Link to="/wallet/recargar" className="flex items-center justify-center gap-2 rounded-2xl bg-ink-900 py-3 font-semibold text-white">
          <Plus size={18} /> Recargar
        </Link>
        <Link to="/wallet/pagar" className="flex items-center justify-center gap-2 rounded-2xl bg-white py-3 font-semibold text-ink-900 ring-1 ring-slate-200">
          <QrCode size={18} /> Pagar con QR
        </Link>
      </div>

      <h2 className="mb-2 mt-6 text-sm font-bold">Historial de movimientos</h2>
      <div className="space-y-2">
        {wallet?.movements.length === 0 && (
          <p className="rounded-2xl bg-white p-4 text-sm text-slate-500">Aún no hay movimientos. Recargue saldo para comenzar.</p>
        )}
        {wallet?.movements.map((m) => (
          <Link
            key={m.id}
            to={`/wallet/movimiento/${m.id}`}
            className="block rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-100"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{typeLabel(m.type)}</p>
                <p className="text-xs text-slate-500">{m.description}</p>
                <p className="mt-1 text-[11px] text-slate-400">
                  {formatDate(m.createdAt)} · {channelLabel(m.channel)}
                  {m.brandId ? ` · ${brandName(m.brandId)}` : ""}
                </p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${m.signedAmountCents > 0 ? "text-mint-600" : m.signedAmountCents < 0 ? "text-ink-900" : "text-slate-400"}`}>
                  {m.signedAmountCents === 0 ? usd(m.amountCents) : usd(m.signedAmountCents)}
                </p>
                <p className="text-[11px] text-slate-500">{statusLabel(m.status)}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
