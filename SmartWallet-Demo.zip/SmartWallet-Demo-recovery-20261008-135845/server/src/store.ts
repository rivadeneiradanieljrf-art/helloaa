import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createSeed } from "./seed.js";
import type { Database } from "./types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_PATH = join(__dirname, "..", "data", "db.json");

let cache: Database | null = null;
let writeChain: Promise<void> = Promise.resolve();

export async function loadDb(): Promise<Database> {
  if (cache) return cache;
  try {
    const raw = await readFile(DATA_PATH, "utf8");
    cache = JSON.parse(raw) as Database;
    return cache;
  } catch {
    cache = createSeed();
    await persist(cache);
    return cache;
  }
}

export async function resetDb(): Promise<Database> {
  cache = createSeed();
  await persist(cache);
  return cache;
}

export async function mutate<T>(fn: (db: Database) => T): Promise<T> {
  const run = writeChain.then(async () => {
    const db = await loadDb();
    const result = fn(db);
    await persist(db);
    return result;
  });
  writeChain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function persist(db: Database) {
  await mkdir(dirname(DATA_PATH), { recursive: true });
  await writeFile(DATA_PATH, JSON.stringify(db, null, 2), "utf8");
}
